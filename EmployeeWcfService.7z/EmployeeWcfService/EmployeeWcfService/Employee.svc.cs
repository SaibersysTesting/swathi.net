﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;

namespace EmployeeWcfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Employee" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Employee.svc or Employee.svc.cs at the Solution Explorer and start debugging.
    public class Employee : IEmployee
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        ConnectionClass conobj = new ConnectionClass();
        public int Inser_Employee(int eno, string ename, double Salary)
        {

            con = conobj.ProjectConnection();
            con.Open();

            string query = "insert into Employee_tbl values(@prm_eno,@prm_ename,@prm_ salary)";
            cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@prm_eno", eno);
            cmd.Parameters.AddWithValue("@prm_ename", ename);
            cmd.Parameters.AddWithValue("@prm_ salary", Salary);
            cmd.ExecuteNonQuery();

            con.Close();

            return 1;

        }
    }
}
