﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace EmployeeWcfService
{
    public class ConnectionClass
    {
        public SqlConnection ProjectConnection()
        {
            string strconn = ConfigurationManager.ConnectionStrings["Employeeconnection"].ConnectionString;
            SqlConnection con = new SqlConnection(strconn);
            return con;
        }
    }
}